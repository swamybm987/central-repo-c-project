#include<stdio.h>
main()
{
	rev();
}
